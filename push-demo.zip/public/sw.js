/* sw.js (MediMate push demo): shows the reminder the moment the server pushes it, even when the site is closed */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { title: 'MediMate', body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || 'MediMate reminder', {
    body: d.body || '', tag: d.tag || d.doseId || 'medimate', requireInteraction: true,
    data: { doseId: d.doseId, profileId: d.profileId },
    actions: d.doseId ? [{ action: 'taken', title: 'Taken' }, { action: 'snooze', title: 'Snooze 5 min' }] : []
  }));
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const { doseId, profileId } = e.notification.data || {};
  e.waitUntil((async () => {
    if ((e.action === 'taken' || e.action === 'snooze') && doseId) {
      // Works with every tab closed. (In the full app this write goes into the sync queue so it also works offline.)
      await fetch('/api/dose-action', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ doseId, profileId, action: e.action }) }).catch(() => {});
    }
    const all = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    all.forEach(c => c.postMessage({ type: 'dose-action', action: e.action || 'open', doseId }));
    if (e.action) return;                               // a button press does not need to open the app
    return all.length ? all[0].focus() : clients.openWindow('/');
  })());
});

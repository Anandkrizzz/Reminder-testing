/* Run:  npm test */
process.env.TZ = 'UTC';
const assert = require('assert'), crypto = require('crypto');
const { createService, createServer } = require('../push-server.js');
const webpush = require('web-push');

const med = (extra = {}) => ({ id: 'med_1', name: 'Paracetamol', dose: '1 tablet', times: ['08:00'], startDate: '2026-11-26', days: 3, ...extra });
const sub = (n = 1) => ({ endpoint: 'https://push.example/' + n, keys: { p256dh: 'x', auth: 'y' } });
function make(startIso, extra = {}) {
  let t = new Date(startIso).getTime(); const sent = [];
  const svc = createService({ now: () => new Date(t), send: async (s, p) => { if (extra.fail) { const e = new Error('gone'); e.statusCode = extra.fail; throw e; } sent.push({ endpoint: s.endpoint, payload: JSON.parse(p) }); }, ...extra.opts });
  return { svc, sent, advance: ms => { t += ms; } };
}
const tests = []; const test = (n, f) => tests.push([n, f]);

test('sends one push when a dose is due, never twice', async () => {
  const { svc, sent, advance } = make('2026-11-26T08:00:30.000Z');
  svc.subscribe('p1', 0, sub()); svc.setMedicines('p1', 0, [med()]);
  assert.strictEqual(await svc.checkDue(), 1); assert.strictEqual(sent[0].payload.title, 'Time for Paracetamol');
  advance(15000); assert.strictEqual(await svc.checkDue(), 0); assert.strictEqual(sent.length, 1);
});

test('nothing is sent before the dose time', async () => {
  const { svc, sent } = make('2026-11-26T07:59:00.000Z');
  svc.subscribe('p1', 0, sub()); svc.setMedicines('p1', 0, [med()]); await svc.checkDue(); assert.strictEqual(sent.length, 0);
});

test('time zones: 08:00 in India (UTC+5:30) is 02:30 UTC', async () => {
  const { svc, sent } = make('2026-11-26T02:30:10.000Z');
  svc.subscribe('p1', -330, sub()); svc.setMedicines('p1', -330, [med()]);
  assert.strictEqual(await svc.checkDue(), 1); assert.strictEqual(sent.length, 1);
  const early = make('2026-11-26T08:00:10.000Z');                       // 08:00 UTC would be 13:30 in India: not due
  early.svc.subscribe('p1', -330, sub()); early.svc.setMedicines('p1', -330, [med()]); await early.svc.checkDue(); assert.strictEqual(early.sent.length, 0);
});

test('every device of the same person gets the push', async () => {
  const { svc, sent } = make('2026-11-26T08:00:30.000Z');
  svc.subscribe('p1', 0, sub(1)); svc.subscribe('p1', 0, sub(2)); svc.subscribe('p1', 0, sub(2));   // same device twice = one
  svc.setMedicines('p1', 0, [med()]); await svc.checkDue(); assert.deepStrictEqual(sent.map(s => s.endpoint).sort(), ['https://push.example/1', 'https://push.example/2']);
});

test('a dose due before anyone subscribed is still sent shortly after (catch-up)', async () => {
  const { svc, sent } = make('2026-11-26T08:00:30.000Z');
  svc.setMedicines('p1', 0, [med()]); await svc.checkDue(); assert.strictEqual(sent.length, 0);
  svc.subscribe('p1', 0, sub()); await svc.checkDue(); assert.strictEqual(sent.length, 1);
});

test('Taken is recorded as a dose log', async () => {
  const { svc } = make('2026-11-26T08:05:00.000Z');
  svc.subscribe('p1', 0, sub()); svc.setMedicines('p1', 0, [med()]);
  svc.doseAction({ doseId: 'med_1|2026-11-26T08:00:00.000Z', profileId: 'p1', action: 'taken' });
  const l = svc.state().doseLogs; assert.strictEqual(l.length, 1); assert.strictEqual(l[0].status, 'taken'); assert.strictEqual(l[0].medId, 'med_1'); assert.strictEqual(l[0].synced, true);
});

test('Snooze sends the reminder again after the snooze time', async () => {
  const { svc, sent, advance } = make('2026-11-26T08:00:30.000Z', { opts: { snoozeMin: 5 } });
  svc.subscribe('p1', 0, sub()); svc.setMedicines('p1', 0, [med()]); await svc.checkDue();
  svc.doseAction({ doseId: sent[0].payload.doseId, profileId: 'p1', action: 'snooze' });
  advance(4 * 60000); await svc.checkDue(); assert.strictEqual(sent.length, 1);
  advance(2 * 60000); await svc.checkDue(); assert.strictEqual(sent.length, 2); assert.ok(sent[1].payload.body.includes('snoozed'));
});

test('a subscription the push service reports as gone (410) is removed', async () => {
  const { svc } = make('2026-11-26T08:00:30.000Z', { fail: 410 });
  svc.subscribe('p1', 0, sub()); svc.setMedicines('p1', 0, [med()]); await svc.checkDue();
  assert.strictEqual(svc.state().subs.p1.length, 0);
});

test('push messages are encrypted and signed (real web-push library, nothing sent)', async () => {
  const k = webpush.generateVAPIDKeys(); webpush.setVapidDetails('mailto:test@example.com', k.publicKey, k.privateKey);
  const ecdh = crypto.createECDH('prime256v1'); ecdh.generateKeys();
  const subscription = { endpoint: 'https://fcm.googleapis.com/fcm/send/abc', keys: { p256dh: ecdh.getPublicKey().toString('base64url'), auth: crypto.randomBytes(16).toString('base64url') } };
  const d = webpush.generateRequestDetails(subscription, JSON.stringify({ title: 'Time for Paracetamol' }));
  assert.strictEqual(d.method, 'POST'); assert.ok(d.headers.Authorization.startsWith('vapid')); assert.strictEqual(d.headers['Content-Encoding'], 'aes128gcm');
  assert.ok(Buffer.isBuffer(d.body) && d.body.length > 50);
});

test('HTTP API: subscribe, add medicine, push now, dose action, state', async () => {
  const { svc, sent } = make('2026-11-26T08:00:30.000Z');
  const server = createServer(svc, 'PUBLIC_KEY'); await new Promise(r => server.listen(0, r)); const base = 'http://localhost:' + server.address().port;
  const post = (p, b) => fetch(base + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(r => r.json());
  assert.strictEqual((await (await fetch(base + '/api/vapid-public-key')).json()).key, 'PUBLIC_KEY');
  await post('/api/subscribe', { profileId: 'p1', tzOffset: 0, subscription: sub() });
  await post('/api/medicines', { profileId: 'p1', tzOffset: 0, medicines: [med()] });
  assert.strictEqual((await post('/api/push-now', { profileId: 'p1' })).sent, 1);
  await svc.checkDue(); assert.strictEqual(sent.length, 2);
  await post('/api/dose-action', { doseId: sent[1].payload.doseId, profileId: 'p1', action: 'taken' });
  const st = await (await fetch(base + '/api/state?profileId=p1')).json();
  assert.strictEqual(st.subscriptions, 1); assert.strictEqual(st.medicines.length, 1); assert.strictEqual(st.doseLogs.length, 1);
  assert.strictEqual((await fetch(base + '/push-test.html')).status, 200); assert.strictEqual((await fetch(base + '/sw.js')).status, 200);
  assert.strictEqual((await fetch(base + '/data.json')).status, 404); assert.strictEqual((await fetch(base + '/../vapid.json')).status, 404);
  server.close();
});

(async () => {
  let failed = 0;
  for (const [n, f] of tests) { try { await f(); console.log('  PASS  ' + n); } catch (e) { failed++; console.log('  FAIL  ' + n + '\n        ' + e.message); } }
  console.log(failed ? '\n' + failed + ' failed' : '\nAll ' + tests.length + ' tests passed'); process.exit(failed ? 1 : 0);
})();
